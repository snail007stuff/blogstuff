const n="english",s="русский",e={en:n,ru:s};export{e as l};
