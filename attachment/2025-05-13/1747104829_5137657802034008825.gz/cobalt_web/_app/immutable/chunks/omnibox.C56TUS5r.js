import{w as o}from"./index.CdrgBhix.js";const t=o("");export{t as link};
