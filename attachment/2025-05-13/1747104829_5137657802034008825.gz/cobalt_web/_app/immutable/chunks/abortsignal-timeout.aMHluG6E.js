"AbortSignal"in window&&!window.AbortSignal.timeout&&(window.AbortSignal.timeout=t=>{const o=new AbortController;return setTimeout(()=>o.abort("timed out"),t),o.signal});
