const t=e=>{if(window.innerWidth<=750)return`/${e}`;switch(e){case"settings":return"/settings/appearance";case"about":return"/about/general"}};export{t as d};
