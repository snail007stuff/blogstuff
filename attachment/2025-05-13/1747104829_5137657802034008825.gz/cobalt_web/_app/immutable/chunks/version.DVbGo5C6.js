import{r as n}from"./index.CdrgBhix.js";const s=n(void 0,o=>{fetch("/version.json").then(e=>e.json()).then(o).catch(()=>{})});export{s as v};
