import{d as f}from"./settings.B2WDECTA.js";function e(a){return(r,t)=>{if(f[r][t]!==a[r][t])return a[r][t]}}export{e as default};
