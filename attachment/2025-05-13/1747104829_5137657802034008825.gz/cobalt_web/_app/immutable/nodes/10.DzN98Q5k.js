import{s}from"../chunks/scheduler.y4uHs2UB.js";import{S as t,i as e}from"../chunks/index.Cysm1UDV.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
