import{P as m}from"../chunks/19.sETapdUv.js";export{m as component};
