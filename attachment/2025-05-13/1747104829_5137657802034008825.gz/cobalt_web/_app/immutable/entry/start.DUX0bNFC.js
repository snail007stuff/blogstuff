import{c as a}from"../chunks/meowbalt.Dv8KiqNC.js";export{a as start};
